export default function Work(){
    return (
        <>work</>
    );
}